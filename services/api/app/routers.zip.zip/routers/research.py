from ..research.routers import router  # re-export for main include
