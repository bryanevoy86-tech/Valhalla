"""Contract pipeline module."""
