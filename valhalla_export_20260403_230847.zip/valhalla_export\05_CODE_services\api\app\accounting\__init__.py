"""Accounting module."""
