"""
Notification API routes.
"""
