"""Alerts module initialization."""
